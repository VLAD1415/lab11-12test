package models;

public enum ExperimentalTypes {
    LIFTING_BODY, HYPERSONIC, HIGH_ALTITUDE, VTOL
}
